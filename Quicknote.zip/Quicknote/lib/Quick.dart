import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';

import 'Themenotifier.dart';

class Quicker extends StatefulWidget {
  @override
  _QuickerState createState() => _QuickerState();
}

class _QuickerState extends State<Quicker> {
  late TextEditingController _taskController;
  late List<Task> tasks;

  @override
  void initState() {
    super.initState();
    _taskController = TextEditingController();
    tasks = [];
    _loadTasks();
  }

  Future<void> _loadTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      tasks = Task.fromSharedPreferences(prefs);
    });
  }

  Future<void> _saveTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    Task.saveToSharedPreferences(prefs, tasks);
  }

  void _addTask(String task) {
    setState(() {
      Task newTask = Task(task, DateTime.now());
      tasks.add(newTask);
      tasks.sort((a, b) => b.date.compareTo(a.date));
    });
    _saveTasks();
    FocusScope.of(context).unfocus();
  }

  void _updateTask(int index, String newTask) {
    setState(() {
      tasks[index].task = newTask;
    });
    _saveTasks();
  }

  void _removeTask(int index) {
    setState(() {
      tasks.removeAt(index);
    });
    _saveTasks();
  }

  void _showEditDialog(int index) {
    _taskController.text = tasks[index].task;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          content: TextField(
            autofocus: true,
            controller: _taskController,
            maxLines: null,
            style: TextStyle(color: Colors.black),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                if (_taskController.text.isNotEmpty) {
                  _updateTask(index, _taskController.text);
                  _taskController.clear();
                }
                Navigator.of(context).pop();
              },
              child: Text('Save', style: TextStyle(color: Colors.black)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeNotifier = Provider.of<ThemeNotifier>(context);
    final isDarkMode = themeNotifier.isDarkMode;

    return Scaffold(
      body: Container(
        color: isDarkMode ? Colors.black : Colors.white, // Apply theme here
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 50),
            Text(
              'In a Hurry? ',
              style: TextStyle(
                fontSize: 30,
                color: isDarkMode
                    ? Colors.white
                    : Colors.black, // Apply theme here
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 50),
            Center(
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 16.0),
                decoration: BoxDecoration(
                  color: isDarkMode
                      ? Colors.black
                      : Colors.white, // Adjust container color based on theme
                  border: Border.all(
                      color: isDarkMode
                          ? Colors.white
                          : Colors.black), // Adjust border color based on theme
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: TextField(
                  autofocus: true,
                  controller: _taskController,
                  maxLines: 4,
                  style: TextStyle(
                    fontSize: 26.0,
                    color: isDarkMode
                        ? Colors.white
                        : Colors.black, // Adjust text color based on theme
                  ),
                  decoration: InputDecoration(
                    hintText: 'Enter Notes here....',
                    hintStyle: TextStyle(
                      fontSize: 26.0,
                      color: isDarkMode
                          ? Colors.white
                          : Colors
                              .black, // Adjust hint text color based on theme
                    ),
                    fillColor: isDarkMode
                        ? Color.fromARGB(255, 0, 0, 0)
                        : Color.fromARGB(255, 255, 255,
                            255), // Adjust background color based on theme
                    filled: true,
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                          color: isDarkMode
                              ? Colors.white
                              : Colors
                                  .black), // Adjust border color based on theme
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.transparent),
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  cursorColor: isDarkMode
                      ? Colors.white
                      : Colors.black, // Adjust cursor color based on theme
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                if (_taskController.text.isNotEmpty) {
                  _addTask(_taskController.text);
                  _taskController.clear();
                }
              },
              style: ElevatedButton.styleFrom(
                primary: const Color.fromARGB(255, 111, 102, 102),
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              ),
              child: Text(
                'Save',
                style: TextStyle(color: Colors.white),
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: tasks.length,
                itemBuilder: (context, index) {
                  return Dismissible(
                    key: Key(tasks[index].task),
                    onDismissed: (direction) {
                      _removeTask(index);
                    },
                    background: Container(
                      color: Colors.red,
                      child: Icon(Icons.delete, color: Colors.white),
                    ),
                    child: GestureDetector(
                      onTap: () {
                        _showEditDialog(index);
                      },
                      child: Column(
                        children: [
                          Container(
                            padding: EdgeInsets.all(8.0),
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                            child: Column(
                              children: [
                                if (index == 0 ||
                                    !isSameDay(tasks[index].date,
                                        tasks[index - 1].date))
                                  Text(
                                    formatDate(tasks[index].date),
                                    style: TextStyle(
                                      color: isDarkMode
                                          ? Colors.white
                                          : Colors.black, // Apply theme here
                                      fontSize: 18.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                SizedBox(height: 10),
                                ListTile(
                                  title: Text(
                                    tasks[index].task,
                                    style: TextStyle(
                                      color: isDarkMode
                                          ? Colors.white
                                          : Colors.black, // Apply theme here
                                      fontSize: 18.0,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 10),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  String formatDate(DateTime date) {
    final months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    return "${date.day} ${months[date.month - 1]} ${date.year}";
  }

  bool isSameDay(DateTime date1, DateTime date2) {
    return date1.year == date2.year &&
        date1.month == date2.month &&
        date1.day == date2.day;
  }
}

class Task {
  String task;
  DateTime date;

  Task(this.task, this.date);

  static List<Task> fromSharedPreferences(SharedPreferences prefs) {
    List<String>? taskStrings = prefs.getStringList('tasks');
    List<Task> tasks = [];
    if (taskStrings != null) {
      for (String taskString in taskStrings) {
        List<String> parts = taskString.split(',');
        if (parts.length == 2) {
          String task = parts[0];
          DateTime date = DateTime.parse(parts[1]);
          tasks.add(Task(task, date));
        }
      }
    }
    return tasks;
  }

  static void saveToSharedPreferences(
      SharedPreferences prefs, List<Task> tasks) {
    List<String> taskStrings = tasks
        .map((task) => "${task.task},${task.date.toIso8601String()}")
        .toList();
    prefs.setStringList('tasks', taskStrings);
  }
}
