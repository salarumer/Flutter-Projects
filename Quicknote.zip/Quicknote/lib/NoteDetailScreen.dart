import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import 'Ads_Helper.dart';

class NoteDetailScreen extends StatefulWidget {
  final Map<String, String> note;

  const NoteDetailScreen({Key? key, required this.note}) : super(key: key);

  @override
  State<NoteDetailScreen> createState() => _NoteDetailScreenState();
}

class _NoteDetailScreenState extends State<NoteDetailScreen> {
  late BannerAd _bottomBannerAd;
  bool _isBottomBannerAdLoaded = false;

  void _createBottomBannerAd() {
    _bottomBannerAd = BannerAd(
      adUnitId: AdHelper.bannerAdUnitId,
      size: AdSize.banner,
      request: AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) {
          setState(() {
            _isBottomBannerAdLoaded = true;
          });
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
        },
      ),
    );
    _bottomBannerAd.load();
  }

  @override
  void initState() {
    super.initState();

    _createBottomBannerAd();
  }

  @override
  void dispose() {
    super.dispose();
    _bottomBannerAd.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: _isBottomBannerAdLoaded
          ? Container(
              height: _bottomBannerAd.size.height.toDouble(),
              width: _bottomBannerAd.size.width.toDouble(),
              child: AdWidget(ad: _bottomBannerAd),
            )
          : null,
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 100,
            ),
            Center(
              child: Text(
                'Title:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 42,
                  color: Colors.blue, // Set title color to blue
                ),
              ),
            ),
            SizedBox(height: 8),
            Center(
              child: Text(
                widget.note['title'] ?? '',
                style: Theme.of(context).textTheme.bodyText1!.copyWith(
                      fontSize: 20, // Set the desired font size
                    ),
              ),
            ),
            SizedBox(height: 38), // Add spacing
            Center(
              child: Text(
                'Description:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 24,
                  color: Colors.blue, // Set description color to blue
                ),
              ),
            ),
            SizedBox(height: 8),
            Center(
              child: Text(
                widget.note['description'] ?? '',
                style: Theme.of(context).textTheme.bodyText1!.copyWith(
                      fontSize: 20, // Set the desired font size
                    ), // Use theme text style for the description
              ),
            ),
          ],
        ),
      ),
    );
  }
}
