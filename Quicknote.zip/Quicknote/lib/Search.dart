import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'Ads_Helper.dart';
import 'NoteDetailScreen.dart';

class SearchScreen extends StatefulWidget {
  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  String _searchQuery = '';
  List<Map<String, String>> _notes = [];
  List<Map<String, String>> _filteredNotes = [];

  @override
  void initState() {
    super.initState();
    _loadNotes();
    _createBottomBannerAd();
  }

  late BannerAd _bottomBannerAd;
  bool _isBottomBannerAdLoaded = false;

  void _createBottomBannerAd() {
    _bottomBannerAd = BannerAd(
      adUnitId: AdHelper.bannerAdUnitId,
      size: AdSize.banner,
      request: AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) {
          setState(() {
            _isBottomBannerAdLoaded = true;
          });
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
        },
      ),
    );
    _bottomBannerAd.load();
  }

  @override
  void dispose() {
    super.dispose();
    _bottomBannerAd.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: _isBottomBannerAdLoaded
          ? Container(
              height: _bottomBannerAd.size.height.toDouble(),
              width: _bottomBannerAd.size.width.toDouble(),
              child: AdWidget(ad: _bottomBannerAd),
            )
          : null,
      body: Column(
        children: [
          SizedBox(
            height: 100,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              style: TextStyle(fontSize: 40),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                  _filterNotes();
                });
              },
              decoration: InputDecoration(
                hintText: 'Search...',
                prefixIcon: Icon(Icons.search),
                suffixIcon: IconButton(
                  icon: Icon(Icons.clear),
                  onPressed: () {
                    setState(() {
                      _searchQuery = '';
                      _filterNotes();
                    });
                  },
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20.0),
                ),
              ),
            ),
          ),
          Expanded(
            child: _searchQuery.isEmpty
                ? SizedBox() // Display nothing if search query is empty
                : CustomScrollView(
                    slivers: [
                      SliverPadding(
                        padding: const EdgeInsets.all(16.0),
                        sliver: SliverGrid(
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            mainAxisSpacing: 10.0,
                            crossAxisSpacing: 10.0,
                            childAspectRatio: 1.0,
                          ),
                          delegate: SliverChildBuilderDelegate(
                            (context, index) {
                              final note = _filteredNotes[index];
                              return _buildNoteCard(note, index);
                            },
                            childCount: _filteredNotes.length,
                          ),
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildNoteCard(Map<String, String> note, int index) {
    Color backgroundColor = _getBackgroundColor(index);

    return InkWell(
      onTap: () {
        // Navigate to a new screen to display the whole note
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NoteDetailScreen(note: note),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(12.0),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 3,
              blurRadius: 7,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _truncateText(note['title'] ?? '', 8),
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
              ),
              SizedBox(height: 8.0),
              Text(
                _truncateText(note['description'] ?? '', 30),
                style: TextStyle(fontSize: 15),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _truncateText(String text, int maxLength) {
    if (text.length <= maxLength) {
      return text;
    }
    return text.substring(0, maxLength).trim() + '...';
  }

  Color _getBackgroundColor(int index) {
    List<Color> colors = [
      Color.fromARGB(255, 117, 211, 255),
      Colors.lightGreen,
      Colors.orange[200]!,
      Colors.purple[200]!,
      Colors.red[200]!,
      Colors.teal[200]!,
      Colors.yellow[200]!,
      Colors.indigo[200]!,
      Colors.pink[200]!,
      Colors.amber[200]!,
    ];
    return colors[index % colors.length];
  }

  Future<void> _loadNotes() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? noteStrings = prefs.getStringList('notes');
    if (noteStrings != null) {
      setState(() {
        _notes = noteStrings.map((note) {
          var parts = note.split('|');
          return {'title': parts[0], 'description': parts[1]};
        }).toList();
        _filteredNotes = List.from(_notes);
      });
    }
  }

  void _filterNotes() {
    if (_searchQuery.isEmpty) {
      setState(() {
        _filteredNotes = [];
      });
    } else {
      setState(() {
        _filteredNotes = _notes.where((note) {
          return note['title']!
                  .toLowerCase()
                  .contains(_searchQuery.toLowerCase()) ||
              note['description']!
                  .toLowerCase()
                  .contains(_searchQuery.toLowerCase());
        }).toList();
      });
    }
  }
}
