import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'Ads_Helper.dart';
import 'NoteDetailScreen.dart';
import 'Theme.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late BannerAd _bottomBannerAd;
  bool _isBottomBannerAdLoaded = false;
  List<Map<String, String>> notes = [];

  void _createBottomBannerAd() {
    _bottomBannerAd = BannerAd(
      adUnitId: AdHelper.bannerAdUnitId,
      size: AdSize.banner,
      request: AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) {
          setState(() {
            _isBottomBannerAdLoaded = true;
          });
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
        },
      ),
    );
    _bottomBannerAd.load();
  }

  @override
  void initState() {
    super.initState();
    _loadNotes();
    _createBottomBannerAd();
  }

  @override
  void dispose() {
    super.dispose();
    _bottomBannerAd.dispose();
  }

  Future<void> _loadNotes() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      notes = prefs.getStringList('notes')?.map((note) {
            var parts = note.split('|');
            return {'title': parts[0], 'description': parts[1]};
          }).toList() ??
          [];
    });
  }

  void _deleteNote(int index) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? noteStrings = prefs.getStringList('notes');
    if (noteStrings != null) {
      noteStrings.removeAt(index);
      await prefs.setStringList('notes', noteStrings);
      _loadNotes(); // Refresh notes after deletion
    }
  }

  void _deleteNoteDialog(int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(20.0), // Set circular border radius
          ),
          title: Text('Delete Note'),
          content: Text('Are you sure you want to delete this note?'),
          actions: [
            TextButton(
              onPressed: () {
                _deleteNote(index);
                Navigator.pop(context);
              },
              style: TextButton.styleFrom(
                primary: Colors.red, // Set text color to red
              ),
              child: Text('Delete'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  void _updateNoteDialog(BuildContext context, Map<String, String> note) {
    TextEditingController titleController =
        TextEditingController(text: note['title']);
    TextEditingController descriptionController =
        TextEditingController(text: note['description']);

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(20.0), // Set circular border radius
          ),
          title: Text('Update Note'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                decoration: InputDecoration(
                  labelText: 'Title',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 8),
              TextField(
                controller: descriptionController,
                decoration: InputDecoration(
                  labelText: 'Description',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                _saveEditedNote(
                    note, titleController.text, descriptionController.text);
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.blue, // Set button color to blue
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(20.0), // Set circular border radius
                ),
              ),
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: _isBottomBannerAdLoaded
          ? Container(
              height: _bottomBannerAd.size.height.toDouble(),
              width: _bottomBannerAd.size.width.toDouble(),
              child: AdWidget(ad: _bottomBannerAd),
            )
          : null,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 66.0, left: 16.0, right: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'QuickNote!',
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                ThemeToggleIcon(),
              ],
            ),
          ),
          SizedBox(
            height: 50,
          ),
          Expanded(
            child: notes.isEmpty // Check if the notes list is empty
                ? Center(
                    child: Text(
                      'No current notes',
                      style: TextStyle(fontSize: 20),
                    ),
                  )
                : CustomScrollView(
                    slivers: [
                      SliverGrid(
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          mainAxisSpacing: 10.0,
                          crossAxisSpacing: 10.0,
                          childAspectRatio: 1.0,
                        ),
                        delegate: SliverChildBuilderDelegate(
                          (context, index) {
                            return _buildNoteCard(notes[index], index);
                          },
                          childCount: notes.length,
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildNoteCard(Map<String, String> note, int index) {
    // Define a list of colors to choose from
    List<Color> colors = [
      Color.fromARGB(255, 117, 211, 255),
      Colors.lightGreen,
      Colors.orange[200]!,
      Colors.purple[200]!,
      Colors.red[200]!,
      Colors.teal[200]!,
      Colors.yellow[200]!,
      Colors.indigo[200]!,
      Colors.pink[200]!,
      Colors.amber[200]!,
    ];

    // Use modulo operator to ensure the index is within the bounds of the colors list
    Color backgroundColor = colors[index % colors.length];

    // Function to truncate text to a certain number of words
    String truncateText(String text, int maxLength) {
      if (text.length <= maxLength) {
        return text;
      }
      return text.substring(0, maxLength).trim() + '...';
    }

    return InkWell(
      onTap: () {
        // Navigate to a new screen to display the whole note
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NoteDetailScreen(note: note),
          ),
        );
      },
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(12.0),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 3,
              blurRadius: 7,
              offset: Offset(0, 3), // changes position of shadow
            ),
          ],
        ),
        child: Stack(
          children: [
            // Three white holes
            Positioned(
              top: 0,
              left: MediaQuery.of(context).size.width * 0.35,
              child: Container(
                width: 20,
                height: 20,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                ),
              ),
            ),
            Positioned(
              top: 0,
              right: MediaQuery.of(context).size.width * 0.35,
              child: Container(
                width: 20,
                height: 20,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                ),
              ),
            ),
            Positioned(
              top: 0,
              left: MediaQuery.of(context).size.width * 0.5,
              child: Container(
                width: 20,
                height: 20,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                ),
              ),
            ),
            // Popup Menu
            Positioned(
              top: 8.0,
              right: 8.0,
              child: PopupMenuButton(
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(20.0), // Set circular border radius
                ),
                itemBuilder: (BuildContext context) => [
                  PopupMenuItem(
                    value: 'update',
                    child: Row(
                      children: [
                        Icon(Icons.edit, color: Colors.blue),
                        SizedBox(width: 8),
                        Text('Update'),
                      ],
                    ),
                  ),
                  PopupMenuItem(
                    value: 'delete',
                    child: Row(
                      children: [
                        Icon(Icons.delete, color: Colors.red),
                        SizedBox(width: 8),
                        Text('Delete'),
                      ],
                    ),
                  ),
                ],
                onSelected: (String value) {
                  if (value == 'update') {
                    _updateNoteDialog(context, note);
                  } else if (value == 'delete') {
                    _deleteNoteDialog(index);
                  }
                },
              ),
            ),
            // Note content
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    truncateText(note['title'] ?? '', 8), // Limit to 10 words
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    truncateText(
                        note['description'] ?? '', 30), // Limit to 30 words
                    style: TextStyle(fontSize: 15),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _saveEditedNote(Map<String, String> oldNote, String newTitle,
      String newDescription) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? noteStrings = prefs.getStringList('notes');
    if (noteStrings != null) {
      int index =
          noteStrings.indexOf('${oldNote['title']}|${oldNote['description']}');
      if (index != -1) {
        noteStrings[index] = '$newTitle|$newDescription';
        await prefs.setStringList('notes', noteStrings);
        _loadNotes();
      }
    }
  }
}
